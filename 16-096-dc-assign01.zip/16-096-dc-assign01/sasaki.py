'''
    SASAKI ALGORITHM

    Name - Tanmay Kalani
    Batch - UG3
    Roll No. - S20160010096
'''
import multiprocessing, random, sys

number_of_processes, operator, print_round = 0, '>', 1

'''
    CREATE CONNECTIONS IN A PIPE AND LINK PROCESSES
'''
def createConnections(number_of_processes):
    connections = [multiprocessing.Pipe(duplex=True) for i in range(number_of_processes-1)]
    
    processes = [Process(0, None, connections[0][0])]
    processes.extend([Process(i, connections[i-1][1], connections[i][0]) for i in range(1, number_of_processes-1)])
    processes.append(Process(number_of_processes-1, connections[number_of_processes-2][1], None))
    return processes

'''
    OUTPUT COMMAND LINE ERRORS
'''
def printCommandLineArgumentsError():
    error_message = "To run File : python3 <<FILENAME>>.py <<NUMBER_OF_PROCESSES>> <<OPERATOR>>\n"
    error_message += "NUMBER_OF_PROCESSES : Integer\n"
    error_message += "OPERATOR : 0 -> Ascending, \t \t 1 -> Descending\n"
    print(error_message)

'''
    PRINT INITIAL AND FINAL STATES IN 'n_minus_1_output.txt'
'''
def printState(processes, round):
    print(round)
    print("Process \t\t State")
    with open("sasaki_output.txt", "w+") as output_file:
        output_file.write("Initial States \n\n")
        output_file.write("Process \t\t State\n")
        for process in processes:
            state = "P{} ( {} ) \t\t {} {} | {} {}".format(process.index+1, process.area, process.left_value if process.left_value else '-', 'U' if process.left_marker else '', process.right_value if process.right_value else '-', 'U' if process.right_marker else '')
            print(state)
            output_file.write(state+"\n")
        print('{}'.format('*'*50))
        output_file.write('{}\n'.format('*'*50))
        output_file.write("Final States : \n\n")
        output_file.write("Process \t\t State\n")
        output_file.close()

'''
    SWAP VALUES
'''
def swap(val1, val2):
    return val2, val1

'''
    COMPARE VALUES BASED ON THE OPERATOR
'''
def compare(val1, val2):
        if operator == '>':
            return val1 > val2
        else:
            return val2 > val1

'''
    CLASS MESSAGE
'''
class Message():
    def __init__(self, value, from_index, to_index, unique_marker):
        self.value = value
        self.unique_marker = unique_marker
        self.from_index = from_index
        self.to_index = to_index

'''
    CLASS PROCESS AND ITS ATTRIBUTES AND METHODS
'''
class Process(multiprocessing.Process):
    def __init__(self, index, left_process, right_process):
        multiprocessing.Process.__init__(self)
        num = random.randint(0, 10**4)

        self.index = index
        self.left_process, self.right_process = left_process, right_process
        self.area, self.value = 0, num
        self.right_marker, self.left_marker = False, False

        if left_process is None:
            self.left_value = None
            self.area = self.area - 1
            self.right_marker = True
        else:
            self.left_value = num
        if right_process is None:
            self.right_value = None
            self.left_marker = True
        else:
            self.right_value = num

    def operateOnMessage(self, message):
        if message.to_index > message.from_index:
            if compare(self.left_value, message.value):
                if message.unique_marker:
                    self.area -= 1
                if self.left_marker:
                    self.area += 1
                self.left_value = message.value
                self.left_marker = message.unique_marker
        else:
            if compare(message.value, self.right_value):
                self.right_value = message.value
                self.right_marker = message.unique_marker

    def receive(self, socket):
        if socket is "L":
            if self.left_process is not None:
                message = self.left_process.recv()
                self.operateOnMessage(message)
        elif socket is "R":
            if self.right_process is not None:
                message = self.right_process.recv()
                self.operateOnMessage(message)

    def run(self):
        for i in range(0, number_of_processes):
            if i != 0:
                if self.left_process is not None:
                    self.receive("L")
                if self.right_process is not None:
                    self.receive("R")
                if self.left_value is not None and self.right_value is not None:
                    if compare(self.right_value, self.left_value):
                        self.left_value, self.right_value = swap(self.left_value, self.right_value)
                        self.left_marker, self.right_marker = swap(self.left_marker, self.right_marker)
            if self.left_process is not None:
                self.left_process.send(Message(self.left_value, self.index, self.index-1, self.left_marker))
            if self.right_process is not None:
                self.right_process.send(Message(self.right_value, self.index, self.index+1, self.right_marker))
            if i % print_round == 0:
                print("R{} \t -> \t P{} ( {} ): {} {} | {} {}".format(i, self.index, self.area, self.left_value if self.left_value else '-', ' U' if self.left_marker else '', self.right_value if self.right_value else '-', ' U' if self.right_marker else ''))
            
        self.value = self.right_value if self.area == -1 else self.left_value
        print("P{} Value = {}".format(self.index+1, self.value))
        with open("sasaki_output.txt", "a") as output_file:
            output_file.write("P{} ( {} ) \t\t {}\n".format(self.index+1, self.area, self.value))

'''
    MAIN FUNCTION
    -- PROCESSING OF COMMAND LINE ARGUMENTS TO DEFINE PARAMETERS
'''
if __name__ == '__main__':
    if len(sys.argv) > 1:
        try:
            number_of_processes = int(sys.argv[1])
            operator = '>' if int(sys.argv[2]) else '<'
            
            if number_of_processes <= 10:
                print_round = 2
            elif number_of_processes <= 50:
                print_round = 5
            else:
                print_round = 10

            processes = createConnections(number_of_processes)
            printState(processes, 'Initial State')

            for process in processes:
                process.start()
            
            for process in processes:
                process.join()

        except Exception as e:
            print(e)
            printCommandLineArgumentsError()
            sys.exit(0)
    else:
        printCommandLineArgumentsError()