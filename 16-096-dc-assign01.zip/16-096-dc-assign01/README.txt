REQUIREMENTS

python3
multiprocessing
random

*******************************************************************************

SASAKI ALGORITHM

    NUMBER_OF_PROCESSES : Integer
    OPERATOR :  0 -> Ascending Order
                1 -> Descending Order

    -$ python3 sasaki.py <<NUMBER_OF_PROCESSES>> <<OPERATOR>>

*******************************************************************************

N-MINUS-1 ALGORITHM

    NUMBER_OF_PROCESSES : Integer
    OPERATOR :  0 -> Ascending Order
                1 -> Descending Order

    -$ python3 n_minus_1.py <<NUMBER_OF_PROCESSES>> <<OPERATOR>>