'''
    N-1 SORTING ALGORITHM

    Name - Tanmay Kalani
    Batch - UG3
    Roll No. - S20160010096
'''
import multiprocessing, random, sys

number_of_processes, operator, print_round = 0, '>', 1

'''
    CREATE CONNECTIONS IN A PIPE AND LINK PROCESSES
'''
def createConnections(number_of_processes):
    connections = [multiprocessing.Pipe(duplex=True) for i in range(number_of_processes-1)]
    
    processes = [Process(0, None, connections[0][0])]
    processes.extend([Process(i, connections[i-1][1], connections[i][0]) for i in range(1, number_of_processes-1)])
    processes.append(Process(number_of_processes-1, connections[number_of_processes-2][1], None))
    return processes

'''
    OUTPUT COMMAND LINE ERRORS
'''
def printCommandLineArgumentsError():
    error_message = "To run File : python3 <<FILENAME>>.py <<NUMBER_OF_PROCESSES>> <<OPERATOR>>\n"
    error_message += "NUMBER_OF_PROCESSES : Integer\n"
    error_message += "OPERATOR : 0 -> Ascending, \t \t 1 -> Descending\n"
    print(error_message)

'''
    PRINT INITIAL AND FINAL STATES IN 'n_minus_1_output.txt'
'''
def printState(processes, round):
    print(round)
    print("Process \t Value")
    with open("n_minus_1_output.txt", "w+") as output_file:
        output_file.write("Initial States \n\n")
        output_file.write("Process \t\t State\n")
        for process in processes:
            state = "P{} \t\t\t {} ".format(process.index+1, process.value)
            print(state)
            output_file.write(state+"\n")
        print('{}'.format('*'*50))
        output_file.write('{}\n'.format('*'*50))
        output_file.write("Final States : \n\n")
        output_file.write("Process \t\t State\n")
        output_file.close()

'''
    COMPARE VALUES BASED ON THE OPERATOR
'''
def compare(val1, val2):
    if operator == '>':
        return val1 > val2
    else:
        return val2 > val1

'''
    CLASS MESSAGE
'''
class Message():

    def __init__(self, from_index, to_index, value, type_):
        self.from_index = from_index
        self.to_index = to_index
        self.value = value
        self.type = type_

'''
    CLASS PROCESS AND ITS ATTRIBUTES AND METHODS
'''
class Process(multiprocessing.Process):

    def __init__(self, index, left_process, right_process):
        multiprocessing.Process.__init__(self)

        self.index = index
        self.left_process = left_process
        self.right_process = right_process
        self.value = random.randint(1, 100**2)
    
    def operateOnMessage(self, message):
        if message.type == 'SEND':
            if compare(message.value, self.value) and message.from_index > self.index:
                self.right_process.send(Message(self.index, message.from_index, self.value, "REPLY"))
                self.value = message.value
            elif compare(self.value, message.value) and message.from_index < self.index:
                self.left_process.send(Message(self.index, message.from_index, self.value, "REPLY"))
                self.value = message.value
            else:
                msg = Message(self.index, message.from_index, message.value, "REPLY")
                if message.from_index < self.index:
                    self.left_process.send(msg)
                else:
                    self.right_process.send(msg)
        elif message.type == 'REPLY':
            self.value = message.value
    
    def receive(self, socket):
        if socket is "L":
            if self.left_process is not None:
                message = self.left_process.recv()
                self.operateOnMessage(message)
        elif socket is "R":
            if self.right_process is not None:
                message = self.right_process.recv()
                self.operateOnMessage(message)

    def run(self):
        for i in range(number_of_processes-1):
            if self.index % 2 == i % 2:
                if self.index > 0:
                    self.left_process.send(Message(self.index, self.index-1, self.value, 'SEND'))
                    self.receive("L")
                if self.index < number_of_processes-1:
                    self.right_process.send(Message(self.index, self.index+1, self.value, 'SEND'))
                    self.receive("R")
            else:
                self.receive("L")
                self.receive("R")
            if i % print_round == 0:
                print("R{} \t -> \t P{} : {}\n".format(i, self.index+1, self.value), end="")
        
        print("P{} Value = {}".format(self.index+1, self.value))
        with open("n_minus_1_output.txt", "a") as output_file:
            output_file.write("P{} \t\t\t {}\n".format(self.index+1, self.value))

'''
    MAIN FUNCTION
    -- PROCESSING OF COMMAND LINE ARGUMENTS TO DEFINE PARAMETERS
'''
if __name__ == '__main__':
    if len(sys.argv) > 1:
        try:
            number_of_processes = int(sys.argv[1])
            operator = '>' if int(sys.argv[2]) else '<'

            if number_of_processes <= 10:
                print_round = 2
            elif number_of_processes <= 50:
                print_round = 5
            else:
                print_round = 10

            processes = createConnections(number_of_processes)
            printState(processes, 'Initial States')

            for process in processes:
                process.start()
            
            for process in processes:
                process.join()

        except Exception as e:
            print(e)
            printCommandLineArgumentsError()
            sys.exit(0)
    else:
        printCommandLineArgumentsError()